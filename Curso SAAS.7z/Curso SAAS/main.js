import express from 'express'
import {connect} from './database/mongo.js'
import user_routes from './routes/user.routes.js'
const app = express()

app.use(express.json())

const porta = 7878

app.use('/user', user_routes)
//app.use('/document', document_routes)


connect().then(() => {
    app.listen(porta, () => {
        console.log(`aplicação subiu na porta ${porta}`)
        console.log('rodando na porta', porta)
    })
}).catch((erro) => {
    console.error('erro na conexão', erro)
})