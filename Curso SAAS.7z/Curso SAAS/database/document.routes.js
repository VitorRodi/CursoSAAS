import express from 'express';
import { create } from '../controllers/document.controller.js';

const document_routes = express.Router()

document_routes.post('/create', create)

export default document_routes
