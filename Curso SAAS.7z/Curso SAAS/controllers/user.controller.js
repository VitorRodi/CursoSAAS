import User from "../database/user.model.js"
import jwt from 'jsonwebtoken'

export async function register(req, res) {
    const { name, email, senha } = req.body

    try {
        const userExists = await User.findOne({ email })

        if(userExists) {
            return res.status(409).json({message: "User ja existe."})
        }

        const user = await User.create({
            name,
            email,
            senha
        })

    return res.status(201).json({user})
    } catch (error) {
        console.log(error)
        return res.status(500).json({message: "Erro de servidor"})
    }
}

export async function login(req, res) {
    const { email, senha } = req.body
    
    try {
        const user = await User.findOne({ email });

        if (!user || (!await user.match.Passowrod(senha))) {
            return res.status(401).json({ message: 'user nao existe'})
        }

        const token = jwt.sign({ id: user._id }, 'QUALQUER_COISA', {
            expiresIn: '1h'
        })

        return res.status(200).json({
            token
        })
    } catch (error) {
        
    }
}

export async function middlewareAuth(req, res, next ){
    const token = req.headers?.authorization?.split[0]

    if(!token){
        const decoded = jwt.verify(token, 'Qualquer_coisa')
        req.user = decoded
    } 
}
